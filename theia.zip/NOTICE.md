# Notices for Eclipse Theia

This content is produced and maintained by the Eclipse Theia project.

* Project home: <https://projects.eclipse.org/projects/ecd.theia>

## Trademarks

Eclipse Theia is a trademark of the Eclipse Foundation.

## Copyright

All content is the property of the respective authors or their employers. For
more information regarding authorship of content, please consult the listed
source code repository logs.

## Declared Project Licenses

This program and the accompanying materials are made available under the terms
of the Eclipse Public License v. 2.0 which is available at
<https://www.eclipse.org/legal/epl-2.0>. This Source Code may also be made
available under the following Secondary Licenses when the conditions for such
availability set forth in the Eclipse Public License v. 2.0 are satisfied:
(secondary) GPL-2.0 with Classpath-exception-2.0 which is available at GNU
General Public License v2.0 w/Classpath exception',
'<https://www.gnu.org/software/classpath/license.html>.

SPDX-License-Identifier: EPL-2.0 OR GPL-2.0-only WITH Classpath-exception-2.0

## Source Code

The project maintains the following source code repositories:

* <https://github.com/eclipse-theia/theia>
* <https://github.com/eclipse/theia-generator-plugin>
* <https://github.com/eclipse/theia-yeoman-plugin>
* <https://github.com/eclipse/theia-plugin-packager>
* <https://github.com/eclipse-theia/theia-cpp-extensions>
* <https://github.com/eclipse/theia-python-extension>
* <https://github.com/eclipse/theia-java-extension>
* <https://github.com/eclipse-theia/theia-example>
* <https://github.com/eclipse-theia/cryptodetector>
* <https://github.com/eclipse-theia/generator-theia-extension>

## Third-party Content

This project leverages the following third party content.

chalk (2.4.1)

* License: MIT
* Project: <https://github.com/chalk/chalk>
* Source: <https://github.com/chalk/chalk>

code copied from project cortex-debug (0.1.21)

* License: MIT

Code copied from project Microsoft/vscode (1.31.0)

* License: MIT

Code copied from project Microsoft/vscode (1.32.3)

* License: MIT
* Project: <https://code.visualstudio.com/>
* Source: <https://github.com/Microsoft/vscode>

Code copied from project Microsoft/vscode (1.32.3)

* License: MIT

code copied from project microsoft/vscode (1.33.1)

* License: MIT

Code copied from project Microsoft/vscode (1.33.1)

* License: MIT

Code copied from project Microsoft/vscode (1.34.0)

* License: MIT

Code copied from project microsoft/vscode (1.41.1)

* License: MIT

code copied from project vscode (1.26.0)

* License: MIT

code copied from project vscode (1.31.0)

* License: MIT

code copied from project vscode (1.33.0)

* License: MIT

code copied from project vscode (1.33.0)

* License: MIT

code copied from project vscode (1.34.0)

* License: MIT

code copied from project vscode (1.36.1)

code copied from project vscode (1.36.1)

* License: MIT

code copied from project vscode (1.37.0)

* License: MIT

code copied from project vscode (1.37.0)

* License: MIT

code copied from project vscode-browser-preview (0.4.0)

* License: MIT

Code copied from VS Code (n/a)

* License: MIT

Code copied from VSCode (n/a)

* License: MIT

Code copied from vscode (n/a)

* License: MIT

Code copied from VSCode (n/a)

* License: MIT

Code copied from VSCode (n/a)

* License: MIT

Copied code from project VSCode (n/a)

* License: MIT

CSS copied from VS Code (n/a)

* License: MIT

dugite (1.52.0)

* License: MIT

Electron (3.1.7)

* License: BSD-2-Clause AND BSD-3-Clause AND (MIT OR GPL-2.0) AND Apache-2.0
   AND (BSD-2-Clause OR MIT OR Apache-2.0) AND ISC AND MIT AND X11 AND
   BSD-2-Clause-FreeBSD AND Public-Domain AND Unlicense AND MPL-2.0 AND
   (BSD-3-Clause OR MPL-2.0) AND CC-BY-3.0 AND (AFL-2.0

Electron (4.2.11)

* License: MIT AND BSD-3-Clause AND LicenseRef-Public-Domain

Electron (9.0.2)

* License: MIT AND BSD-3-Clause AND LicenseRef-Public-Domain

electron@2.0.14 (2.0.14)

* License: MIT AND BSD-2-Clause AND Apache-2.0 AND (AFL-2.1 OR BSD-3-Clause)
   AND BSD-3-Clause AND ISC AND X11 AND Public-Domain AND (GPL-2.0 OR MIT) AND
   Unlicense AND IJG AND ICU AND UNICODE-TOU AND NTP AND (MIT OR BSD-3-Clause)
   AND Libpng AND MPL-2.0 AND LGPL-2.1+
* Project: <https://github.com/electron/electron>
* Source: <https://github.com/electron/electron/releases/tag/v2.0.14>

getmac (1.4.6)

* License: MIT
* Project: <https://github.com/bevry/getmac>
* Source: <https://github.com/bevry/getmac>

GH-3397: Implemented the HTTP-based authentication for Git in Electron. (n/a)

* License: MIT

glob promise (3.4.0)

* License: ISC
* Project: <https://github.com/ahmadnassri/glob-promise>
* Source: <https://github.com/ahmadnassri/glob-promise>

Icon configure-inverse.svg (n/a)

* License: MIT
* Project: <https://github.com/Microsoft/vscode>
* Source:
   <https://github.com/Microsoft/vscode/blob/1.35.1/src/vs/workbench/contrib/tasks/common/media/configure-inverse.svg#L1>

Icons copied from microsoft/vscode-icons version:
b73945c70f1117c4e65939dd3e10bdd623cb4ef3 (n/a)

* License: CC-BY-4.0

inversify (5.0.1)

* License: MIT

jschardet (1.6.0)

* License: (LGPL-2.1 OR LGPL-2.1+) AND (MIT OR GPL-2.0)
* Project: <https://www.npmjs.com/package/jschardet>
* Source:
   <https://github.com/aadsm/jschardet/tree/28152dd8db5904dc2cf9aa12ef4f8783f713e79a>

jschardet (2.1.1)

* License: LGPL-2.1 OR LGPL-2.1+

libffmpeg (FFmpeg) Delivered with Electron (3.1.7)

* License: LGPL-2.1+

libffmpeg (FFmpeg) delivered with Electron (4.2.11)

* License: LGPG-2.1-or-later AND BSD-3-Clause AND MIT AND IJG

libffmpeg (FFmpeg) delivered with Electron (9.0.2)

* License: LGPG-2.1-or-later AND BSD-3-Clause AND MIT AND IJG

long.js (3.2.0)

* License: Apache-2.0

micromatch (3.1.10)

* License: MIT
* Project: <https://github.com/micromatch/micromatch>
* Source: <https://github.com/micromatch/micromatch>

monaco-typescript (2.3.0)

* License: MIT
* Project: <https://github.com/Microsoft/monaco-typescript>
* Source: <https://github.com/Microsoft/monaco-typescript.git>

native-keymap (1.2.5)

* License: BSD-3-Clause AND MIT
* Project: <https://github.com/Microsoft/node-native-keymap>
* Source: <https://github.com/Microsoft/node-native-keymap>

node-oniguruma (n/a)

* License: BSD-2-Clause AND GPL-2.0 WITH Autoconf-exception-2.0 AND
   GPL-2.0-or-later WITH libtool-exception AND X11 AND MIT AND Public-Domain

node.js dependencies for Theia (n/a)

* License: MIT AND BSD-3-Clause AND ISC AND Apache-2.0 AND BSD-2-Clause AND
   Zlib AND X11 AND (BSD-3-Clause OR AFL-2.1) AND CC-By-4.0 AND CC-by-2.5-SA AND
   CC0-1.0 AND (BSD-3-Clause OR MPL-2.0) AND Unlicense AND (MIT OR GPL-3.0) AND
   (MIT OR GPL-2.0) AND (Apache-2.0 OR

Preference code copied from vscode (n/a)

ps-list (5.0.1)

* License: MIT
* Project: <https://github.com/sindresorhus/ps-list>
* Source: <https://github.com/sindresorhus/ps-list>

react-perfect-scrollbar:1.5.3 (1.5.3)

* License: MIT
* Project: <https://github.com/goldenyz/react-perfect-scrollbar>
* Source: <https://github.com/goldenyz/react-perfect-scrollbar>

read-pkg (4.0.1)

* License: MIT
* Project: <https://github.com/sindresorhus/read-pkg>
* Source: <https://github.com/sindresorhus/read-pkg>

regular expressions and helper function copied from microsoft/vscode (1.33.1)

* License: MIT

requestretry (3.1.0)

* License: MIT
* Project: <https://github.com/FGRibreau/node-request-retry>
* Source: <https://github.com/FGRibreau/node-request-retry>

rimraf (2.6.2)

* License: ISC

textmate/tcl.tmbundle (n/a)

* License: LicenseRef-Php_Tmbundle

theia npm node (n/a)

* License: BSD-2-Clause OR (MIT OR Apache-2.0) AND (AFL-2.1 OR BSD-3-Clause)
   AND Apache-2.0 AND Artistic-2.0 AND BSD-3-Clause AND (BSD-3-Clause OR MIT)
   AND MPL-2.0 AND CC0-1.0 AND CC-BY-3.0 AND CC-BY-4.0 AND CC-BY-SA-2.5 AND
   GPL-2.0 WITH Autoconf-exception

theia-cpp-extension npm node (n/a)

* License: BSD-2-Clause OR (MIT OR Apache-2.0) AND MIT AND BSD-3-Clause AND
   Zlib AND (MIT OR GPL-3.0) AND OFL-1.1 AND Apache-2.0 AND CC0-1.0 AND
   CC-BY-3.0 AND ISC AND MPL-2.0 AND License-Ref-Public-Domain AND BSL-1.0 AND
   (AFL-2.1 OR BSD-3.0) AND Unlicense AND Artist

tslint (5.10.0)

* License: Apache-2.0 AND MIT
* Project: <http://palantir.github.io/tslint/>
* Source: <https://github.com/palantir/tslint>

typefox/monaco-language-client (0.5.0)

* License: MIT

typescript-formatter (7.2.2)

* License: MIT
* Project: <https://github.com/vvakame/typescript-formatter>
* Source: <https://github.com/vvakame/typescript-formatter>

VS Code (1.33.0)

* License: MIT

VS Code built-in extensions (1.30.1)

* License: Apache-2.0 AND MIT AND Unicode-DFS-2016 AND CC-BY-4.0 AND W3C

vscode (1.26.0)

* License: MIT AND LicenseRef-Php_Tmbundle

vscode (1.26.0)

* License: MIT

vscode (1.31.0)

* License: MIT

vscode-debugadapter-node (n/a)

* License: MIT

vscode-icons (n/a)

* License: CC-BY-4.0 AND MIT

vscode-java (0.36.0)

* License: EPL-1.0

vscode-java (0.44.0)

* License: EPL-1.0

vscode-java-debug (0.15.0)

* License: MIT

webdriverio (n/a)

* License: MIT
* Project: <http://webdriver.io/>
* Source: <https://github.com/webdriverio/webdriverio.git>

when (3.7.8)

* License: MIT
* Project: <https://github.com/cujojs/when>
* Source: <https://github.com/cujojs/when>

wjordan/browser-path SHA6719d19077b1454bff8b802f9be79cb1b69ebe7e (n/a)

* License: MIT

xterm-addon-fit (0.3.0)

* License: MIT

xterm-addon-search (0.5.0)

* License: MIT

xterm.js (3.9.1)

* License: MIT
* Project: <https://xtermjs.org/>
* Source: <https://github.com/xtermjs/xterm.js>

xterm.js (4.4)

* License: MIT

yargs (12.0.1)

* License: MIT
* Project: <http://yargs.js.org/>
* Source: <https://github.com/yargs/yargs>

yeoman environment (2.3.0)

* License: BSD-2-Clause AND BSD-3-Clause
* Project: <https://github.com/yeoman/environment>
* Source: <https://github.com/yeoman/environment>

yeoman generator (3.0.0)

* License: BSD-2-Clause AND BSD-3-Clause
* Project: <http://yeoman.io>
* Source: <https://github.com/yeoman/generator>

yeoman-generator (2.0)

* License: BSD-2-Clause
* Project: <http://yeoman.io/>
* Source: <https://github.com/yeoman/generator>

yosay (2.0.2)

* License: BSD-2-Clause
* Project: <https://github.com/yeoman/yosay>
* Source: <https://github.com/yeoman/yosay>

## Cryptography

Content may contain encryption software. The country in which you are currently
may have restrictions on the import, possession, and use, and/or re-export to
another country, of encryption software. BEFORE using any encryption software,
please check the country's laws, regulations and policies concerning the import,
possession, or use, and re-export of encryption software, to see if this is
permitted.

## Electron

NOTICE:

Please note Electron combines Chromium and Node.js into a single runtime.
While Electron, Chromium and Node.js are generally licensed under very
permissive MIT and BSD-3-Clause licenses, both Electron and Chromium distribute
FFmpeg.  While FFmpeg is under the LGPL-2.1-or-later license it incorporates
several optional parts and optimizations that are covered by the
GPL-2.0-or-later.  We understand both Electron and Chromium do not distribute
versions of FFmpeg with GPL content enabled; however, FFmpeg may be configured
enabled to work with proprietary codecs.  It is our understanding these
proprietary codecs may be patented; and as a result, may be subject to
licensing fees.

We strongly recommend downstream consumers verify the type of FFmpeg support
configured and modify as required.  More information on instructions to verify
can be found here
<https://github.com/electron/electron/blob/c75c3ef61689733cf422c2cc76d51ce05033be33/docs/development/upgrading-chromium.md#verify-ffmpeg-support>
