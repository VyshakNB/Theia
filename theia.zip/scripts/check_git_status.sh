#!/bin/sh
if [ $(git status --porcelain | wc -c) -gt 0 ];
then
    echo "\nERR: The git repository state changed after the build, this should not happen.\n"
    git --no-pager diff
    echo "\nHINT: Did you update and commit your 'package-lock.json' ?"
    echo "\n      You can also check your '.gitignore'."
    exit 1
fi
